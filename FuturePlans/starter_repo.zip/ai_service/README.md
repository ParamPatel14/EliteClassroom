# AI Microservice (FastAPI)

- Handles LLM interactions, STT and TTS wrappers.
