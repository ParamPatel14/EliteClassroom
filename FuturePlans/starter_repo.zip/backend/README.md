# Backend (Django)

Commands:

- `python -m venv venv`
- `pip install -r requirements.txt`
- `python manage.py migrate`
- `python manage.py runserver`
