# Frontend (Next.js)

Commands:

- `npm install`
- `npm run dev`

Placeholder for Next.js app.