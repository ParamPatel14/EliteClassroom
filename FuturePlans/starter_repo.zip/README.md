# AI-Powered Tutoring Platform - Starter Repository

This starter repo contains skeleton folders for frontend, backend and AI microservice. Fill in implementations as required.

See `/docs` for further guides.